﻿using System;

namespace SoundCloud.NET
{
    public enum HttpMethod
    {
        Get,

        Post,

        Put,

        Delete
    }
}
